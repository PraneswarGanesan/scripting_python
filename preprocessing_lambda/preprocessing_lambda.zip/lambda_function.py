import json
import boto3
import pandas as pd
from io import BytesIO, StringIO
from PIL import Image
import mimetypes
import os
import traceback

s3 = boto3.client('s3')

SUPPORTED_IMAGE_EXT = {'.jpg', '.jpeg', '.png'}
SUPPORTED_TEXT_EXT  = {'.txt', '.md'}
SUPPORTED_CSV_EXT   = {'.csv'}
SUPPORTED_JSON_EXT  = {'.json'}

def _ext(name: str) -> str:
    name = name.lower()
    _, ext = os.path.splitext(name)
    return ext

def list_all_files(bucket: str, prefix: str):
    """List all non-folder objects under prefix."""
    keys = []
    continuation = None
    while True:
        if continuation:
            resp = s3.list_objects_v2(Bucket=bucket, Prefix=prefix, ContinuationToken=continuation)
        else:
            resp = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)
        for it in resp.get('Contents', []):
            key = it['Key']
            if key.endswith('/') or key == prefix:
                continue
            # Return file names relative to prefix (to align with Spring’s ‘files’ list)
            keys.append(key[len(prefix):])
        if resp.get('IsTruncated'):
            continuation = resp.get('NextContinuationToken')
        else:
            break
    return keys

def process_csv(bucket: str, in_key: str, out_key: str):
    obj = s3.get_object(Bucket=bucket, Key=in_key)
    body = obj['Body'].read().decode('utf-8', errors='ignore')
    df = pd.read_csv(StringIO(body))

    # Example preprocessing: drop NA rows & z-score numeric cols
    df = df.dropna()
    numeric_cols = df.select_dtypes(include=['float64', 'int64', 'float32', 'int32']).columns
    if len(numeric_cols) > 0:
        df[numeric_cols] = (df[numeric_cols] - df[numeric_cols].mean()) / df[numeric_cols].std(ddof=0)

    out_buf = StringIO()
    df.to_csv(out_buf, index=False)
    s3.put_object(Bucket=bucket, Key=out_key, Body=out_buf.getvalue().encode('utf-8'))

def process_text(bucket: str, in_key: str, out_key: str):
    obj = s3.get_object(Bucket=bucket, Key=in_key)
    text = obj['Body'].read().decode('utf-8', errors='ignore')

    # Example preprocessing: trim, lowercase, normalize spaces
    cleaned = " ".join(text.strip().split()).lower()

    s3.put_object(Bucket=bucket, Key=out_key, Body=cleaned.encode('utf-8'), ContentType="text/plain")

def process_json(bucket: str, in_key: str, out_key: str):
    obj = s3.get_object(Bucket=bucket, Key=in_key)
    raw = obj['Body'].read().decode('utf-8', errors='ignore')

    data = json.loads(raw)  # raises if invalid JSON

    # Example preprocessing: pretty-print & sort keys
    pretty = json.dumps(data, indent=2, sort_keys=True)

    s3.put_object(Bucket=bucket, Key=out_key, Body=pretty.encode('utf-8'), ContentType="application/json")

def process_image(bucket: str, in_key: str, out_key: str):
    obj = s3.get_object(Bucket=bucket, Key=in_key)
    img_bytes = obj['Body'].read()
    img = Image.open(BytesIO(img_bytes)).convert('RGB')

    # Example preprocessing:
    # - Resize to max side 1024 (keep aspect)
    # - Save as JPEG with optimization
    max_side = 1024
    w, h = img.size
    scale = min(max_side / max(w, h), 1.0)
    if scale < 1.0:
        img = img.resize((int(w * scale), int(h * scale)))

    out = BytesIO()
    img.save(out, format='JPEG', quality=85, optimize=True)
    out.seek(0)

    s3.put_object(Bucket=bucket, Key=out_key, Body=out.getvalue(), ContentType="image/jpeg")

def lambda_handler(event, context):
    """
    Expected payload:
    {
      "bucket": "your-bucket",
      "prefix": "username/project[/optional/subfolder]/",
      "files": ["file1.csv", "images/img1.png", ...]   // optional; if missing or empty => auto-discover
    }
    """
    try:
        bucket = event['bucket']
        prefix = event['prefix']
        files  = event.get('files', [])

        if not prefix.endswith('/'):
            prefix += '/'

        # Auto-discover if files not supplied
        if not files:
            files = list_all_files(bucket, prefix)

        if not files:
            return {
                "statusCode": 200,
                "body": json.dumps({"message": "No files to process under prefix", "prefix": prefix, "processed": [], "errors": []})
            }

        processed = []
        errors = []

        for rel_name in files:
            try:
                # Build S3 keys
                in_key = prefix + rel_name
                ext = _ext(rel_name)
                out_dir = prefix + "processed/"
                if not out_dir.endswith('/'):
                    out_dir += "/"

                # Choose output name / extension
                if ext in SUPPORTED_IMAGE_EXT:
                    base, _ = os.path.splitext(rel_name)
                    out_key = out_dir + base + ".jpg"  # normalize images to JPEG
                    process_image(bucket, in_key, out_key)

                elif ext in SUPPORTED_CSV_EXT:
                    out_key = out_dir + rel_name  # keep .csv
                    process_csv(bucket, in_key, out_key)

                elif ext in SUPPORTED_TEXT_EXT:
                    out_key = out_dir + rel_name  # keep as text
                    process_text(bucket, in_key, out_key)

                elif ext in SUPPORTED_JSON_EXT:
                    out_key = out_dir + rel_name  # keep .json
                    process_json(bucket, in_key, out_key)

                else:
                    # Try mimetype as fallback
                    guess, _ = mimetypes.guess_type(rel_name)
                    if guess and guess.startswith("image/"):
                        base, _ = os.path.splitext(rel_name)
                        out_key = out_dir + base + ".jpg"
                        process_image(bucket, in_key, out_key)
                    else:
                        raise ValueError(f"Unsupported file type: {rel_name}")

                processed.append({"input": in_key, "output": out_key})

            except Exception as e:
                errors.append({"file": rel_name, "error": str(e), "trace": traceback.format_exc()})

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Preprocessing complete",
                "prefix": prefix,
                "processed": processed,
                "errors": errors
            })
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e), "trace": traceback.format_exc()})
        }
